# v2 修正版说明

修复/改进：
- 语音识别在 **iOS PWA(添加到主屏幕)** 上天生不可用：已自动检测并禁用按钮，网页模式仍可用。
- 增强 API 错误提示（包含 CORS 提示）。支持 `?api=` 覆盖 API 地址，并会记忆在 localStorage。
- Service Worker 升级 v2，加入 `skipWaiting/clients.claim()`，并提供“🔄 强制更新”按钮以清缓存防止旧版本缓存干扰。
- Luggage 按钮明确为中英切换（🌐 语言 Language），并持久化语言选择。
- 保留：相机实时识别、提前确认、拍照/相册识别、一致的 OCR 流程与投票、一次授权优化。

部署：
- 直接上传到 HTTPS 静态托管（GitHub Pages/Netlify/Vercel/Cloudflare Pages/Nginx）。
- 首次进入建议点“🔄 强制更新”确保拿到 v2。

排查 API 不通：
- 打开页面后，输入 5 位序列号→点“生成密码”；若失败，页面会提示是否为 CORS 问题。
- Cloudflare Worker 需设置响应头：`Access-Control-Allow-Origin: *` `Access-Control-Allow-Headers: *`。

更改 API 地址：
- 在 URL 后加参数：`?api=https://你的worker域名`，或在控制台 `localStorage.API_BASE='https://...'` 然后刷新。